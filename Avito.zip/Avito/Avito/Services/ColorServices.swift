//
//  ColorServices.swift
//  Avito
//
//

import UIKit

struct Colors {
    static var lightBlue = UIColor(red: 30, green: 174, blue: 255)
    static var lightGray = UIColor(red: 248, green: 248, blue: 248)
}

